import{e}from"./JypfP0gL.js";e();
