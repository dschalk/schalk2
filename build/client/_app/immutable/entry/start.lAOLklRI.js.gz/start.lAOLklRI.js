import{l as o,a as r}from"../chunks/GFxp9hQv.js";export{o as load_css,r as start};
